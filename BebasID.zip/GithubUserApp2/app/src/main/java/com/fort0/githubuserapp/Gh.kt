package com.fort0.githubuserapp

data class Gh(
        var fname: String = "",
        var uname: String = "",
        var userpic: Int = 0
)