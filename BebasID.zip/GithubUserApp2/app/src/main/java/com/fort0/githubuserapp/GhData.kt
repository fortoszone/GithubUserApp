package com.fort0.githubuserapp

object GhData {
    private val fname = arrayOf(
        "NXzLEM",
        "Syafa Adena",
        "Palguno Wicaksono",
        "Diki Ananta",
        "Andra Antariksa",
        "Nuginity",
        "Made Indra",
        "sadpanda",
        "User1",
        "Kirima"
    )

    private val uname = arrayOf(
        "nxzlem",
        "gvoze32",
        "icaksh",
        "dikiaap",
        "andraantariksa",
        "Nuginity",
        "madeindra",
        "wijaksanapanji",
        "DarkKnightHD1000",
        "Eiikirin"
    )

    private val userpic = intArrayOf(
        R.drawable.a,
        R.drawable.b,
        R.drawable.c,
        R.drawable.d,
        R.drawable.e,
        R.drawable.f,
        R.drawable.g,
        R.drawable.h,
        R.drawable.i,
        R.drawable.j
    )

    val listData: ArrayList<Gh>
        get() {
            val list = arrayListOf<Gh>()
            for (position in fname.indices) {
                val gh = Gh()
                gh.fname = fname[position]
                gh.uname = uname[position]
                gh.userpic = userpic[position]
                list.add(gh)
            }
            return list
        }
}